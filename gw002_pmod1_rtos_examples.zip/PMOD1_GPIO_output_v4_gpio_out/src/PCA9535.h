#ifndef __PCA9535_H__
#define __PCA9535_H__

#include <stdbool.h>
#include <stdint.h>
#include "bsp_api.h"
#include "gw002_pin_config.h"
//#include <gw002_pin_config.h>

#define IOEXPANDERU18_IO_SLAVEADDRESS     0x25   // control IO<8:6> and COMMS Mode for different PMOD types. (1x6,1x12,2x4)
#define IOEXPANDERU19_PWR_SLAVEADDRESS    0x27   // control PMOD power, buttons, secure element

// PCA9535 IO Expander: Internal registers
#define INPUTPORTREGP0_ADDR     0
#define INPUTPORTREGP1_ADDR     1
#define OUTPUTPORTREGP0_ADDR    2
#define OUTPUTPORTREGP1_ADDR    3
#define POLARITYINVREGP0_ADDR   4
#define POLARITYINVREGP1_ADDR   5
#define CONFIGREGP0_ADDR        6
#define CONFIGREGP1_ADDR        7

// IO Expander 1
// PORT 0 - 0=output, 1=input
// bit 0  PMOD4 RESET pin
// bit 1  PMOD3 RESET pin
// bit 2  PMOD2 RESET pin
// bit 3  PMOD1 RESET pin
// bit 4  PMOD4 COMMS Mode pin (Output only)
// bit 5  PMOD3 COMMS Mode pin (Output only)
// bit 6  PMOD2 COMMS Mode pin (Output only)
// bit 7  PMOD1 COMMS Mode pin (Output only)
#define IOEX1_PORT0_CONFIG        0b00000000   // all output

// IO Expander 1
// PORT 1 - 0=output, 1=input
// bit 0  PMOD4 IO7 pin
// bit 1  PMOD4 IO8 pin
// bit 2  PMOD3 IO7 pin
// bit 3  PMOD3 IO8 pin
// bit 4  PMOD2 IO7 pin
// bit 5  PMOD2 IO8 pin
// bit 6  PMOD1 IO7 pin
// bit 7  PMOD1 IO8 pin

#define IOEX1_PORT1_CONFIG        0b00000000   // all output

// PORT 1
#define PMOD1COM_CLR        0b01111111    // for bit and operation
#define PMOD1COM_SET        0b10000000    // for bit or operation

/* reset is IO6 */
#define PMOD1RESET_CLR      0b11110111    // for bit and operation
#define PMOD1RESET_SET      0b00001000    // for bit or operation

#define PMOD1IO6_CLR      0b11110111    // for bit and operation
#define PMOD1IO6_SET      0b00001000    // for bit or operation

// PORT 2
#define PMOD1IO7_CLR      0b10111111    // for bit and operation
#define PMOD1IO7_SET      0b01000000    // for bit or operation

#define PMOD1IO8_CLR      0b01111111    // for bit and operation
#define PMOD1IO8_SET      0b10000000    // for bit or operation

// IO Expander 2
// PORT 0 - 0=output, 1=input
// bit 0  NC (input only)
// bit 1  PMOD1 POWER pin (Output only)
// bit 2  PMOD2 POWER pin (Output only)
// bit 3  PMOD3 POWER pin (Output only)
// bit 4  PMOD4 POWER pin (Output only)
// bit 5  PMOD5 POWER pin (Output only)
// bit 6  PMOD6 POWER pin (Output only)
// bit 7  NC (input only)
#define IOEX2_PORT0_CONFIG        0b10000001   // all output

// IO Expander 2
// PORT 1 - 0=output, 1=input
// bit 0  NC (input only)
// bit 1  NC (input only)
// bit 2  Button 1 pin (Input only)
// bit 3  Button 1 pin (Input only)
// bit 4  Button 1 pin (Input only)
// bit 5  Button 1 pin (Input only)
// bit 6  Secure Element Enable pin (Output only)
// bit 7  NC (input only)
#define IOEX2_PORT1_CONFIG        0b10000011   // all output


ssp_err_t pca3535_open(uint8_t slaveaddr);
ssp_err_t pca3535_register_write(uint8_t slaveaddr, uint8_t regaddr, uint8_t regdata);
ssp_err_t pca3535_register_read(uint8_t slaveaddr, uint8_t regaddr, uint8_t *regdata);



#endif //__PCA9535_H__
