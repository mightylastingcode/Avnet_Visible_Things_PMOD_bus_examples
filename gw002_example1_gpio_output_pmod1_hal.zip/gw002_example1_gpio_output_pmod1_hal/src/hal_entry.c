
/*

    File:    Example 1: 8 bits PMOD1 output port (GPIO)
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    3/11/2018

    SSP version: 1.2.0
    E2 Studio version: 5.3.1.002

    Description: Set 8 GPIO output on PMOD1.   Write different values to PMOD1 for testing purpose.

    <GPIO Type 1 Pmod>

     IO.1 PA05 (S7G2)
     IO.2 PA04
     IO.3 PA03
     IO.4 PA02
     IO.5 P400
     IO.6 Reset (U18 IO Expander port 0.7)
     IO.7 IO7 (U18 IO Expander port 1.6)
     IO.8 IO8 (U18 IO Expander port 1.7)


     Configuration U18 port 0.7 COMM = L
     Direction     U18 port0/1 Direction (all output)
     Power         U19 port 0.1 = H (Enable PMOD1 VCC)

    revision:
    v1 creation
 *
 *
*/

/* HAL-only entry function */

/*-------------------------------------------------------------------------*
 * Includes:
 *-------------------------------------------------------------------------*/

#include "hal_data.h"
#include <pca9535/pca9535.h>

/*-------------------------------------------------------------------------*
 * Constants:
 *-------------------------------------------------------------------------*/


// LED locations
#define LEDGRNPIN  IOPORT_PORT_11_PIN_06
#define LEDBLUPIN  IOPORT_PORT_11_PIN_07
#define LEDORGPIN  IOPORT_PORT_03_PIN_13
#define LEDREDPIN  IOPORT_PORT_03_PIN_14

/*-------------------------------------------------------------------------*
 * Types:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Globals:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Prototypes:
 *-------------------------------------------------------------------------*/
// Subroutine Prototypes
void hal_entry(void);


/*---------------------------------------------------------------------------*
 * Function: hal_entry
 *---------------------------------------------------------------------------*/
/**  Write some 8 bits values to PMOD1.
 *
 */
/*---------------------------------------------------------------------------*/
void hal_entry(void)
{


    const uint8_t u18port0cfg   = 0b00000000;   // all output
    const uint8_t u18port1cfg   = 0b00000000;   // all output
    const uint8_t u18port0outreg= 0b00000000;   // IO6 = L, COMS = L
    const uint8_t u18port1outreg= 0b00000000;   // IO7/8 = L
    const uint8_t u19port0cfg   = 0b10000001;   // all output except unused bits.
    const uint8_t u19port0outreg= 0b00000010;   // PMOD1.vcc enabled.

    g_ioport.p_api->pinWrite(LEDGRNPIN, IOPORT_LEVEL_HIGH);  // turn on green led

    setup_pmod(u18port0cfg,u18port1cfg,u18port0outreg,u18port1outreg,u19port0cfg,u19port0outreg);   // setup pmod1

    write_PMOD1_output(0x55);
    write_PMOD1_output(0xAA);

    while (true) {
        write_PMOD1_output(0x66);
        write_PMOD1_output(0x99);
    }
}


/*-------------------------------------------------------------------------*
 * End of File:  hal_entry.c
 *-------------------------------------------------------------------------*/
