/*

    File: pca9535.c (IO Expander device driver)
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    3/11/2018

    SSP version: 1.2.0
    E2 Studio version: 5.3.1.002

    Description: Basic operations such register read and write

    Requirement: Create SCI_I2C driver (name: g_ioexpander_pmod) with Synergy Thread Configuration.
*/

/*-------------------------------------------------------------------------*
 * Includes:
 *-------------------------------------------------------------------------*/

#include "hal_data.h"
#include <pca9535/pca9535.h>


/*-------------------------------------------------------------------------*
 * Constants:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Types:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Globals:
 *-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------*
 * Prototypes:
 *-------------------------------------------------------------------------*/
// Subroutine Prototypes

// Open the driver
ssp_err_t pca3535_open(void) {
    return (g_ioexpander_pmod.p_api->open(g_ioexpander_pmod.p_ctrl,g_ioexpander_pmod.p_cfg));
}

// Write a byte to a register
ssp_err_t pca3535_register_write(uint8_t regaddr, uint8_t regdata) {
    uint8_t buf[2]; // buffer to hold command, write data

    buf[0] = regaddr;
    buf[1] = regdata;
    return(g_ioexpander_pmod.p_api->write(g_ioexpander_pmod.p_ctrl, buf, 2, false));
}

// Read a byte from a register
ssp_err_t pca3535_register_read(uint8_t regaddr, uint8_t *regdata) {
    uint8_t buf[2]; // buffer to hold command, write data
    ssp_err_t err;   // function return status

    // write the register address
    buf[0] = regaddr;
    err = g_ioexpander_pmod.p_api->write(g_ioexpander_pmod.p_ctrl, buf, 1, false);

    // read the register byte
    if (SSP_SUCCESS == err)
        err = g_ioexpander_pmod.p_api->read(g_ioexpander_pmod.p_ctrl, regdata, 1, false);

    return err;
}

// Set the slave address
ssp_err_t pca3535_setslaveaddress(uint8_t slaveaddr) {
    return (g_ioexpander_pmod.p_api->slaveAddressSet(g_ioexpander_pmod.p_ctrl, (uint16_t) slaveaddr, I2C_ADDR_MODE_7BIT));
}

/*
 *  Write 8 bits value to PMOD1
 *
 *  input: an 8 bits write data
 *  Return : None
 *
 *  Assume : PMOD1 is configured GPIO output for IO6/7/8.
 *
 */
void write_PMOD1_output (uint8_t portdata) {
    ssp_err_t err;          // function return status
    uint8_t write_data;  // data to be written into the register
    uint8_t read_data;   // data to be red from the register

    if (portdata & 0x01)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO1, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO1, IOPORT_LEVEL_LOW);

    if (portdata & 0x02)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO2, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO2, IOPORT_LEVEL_LOW);

    if (portdata & 0x04)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO3, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO3, IOPORT_LEVEL_LOW);

    if (portdata & 0x08)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO4, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO4, IOPORT_LEVEL_LOW);

    if (portdata & 0x10)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO5, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO5, IOPORT_LEVEL_LOW);

    // change the slave address for U18 expander
    err = pca3535_setslaveaddress(IOEXPANDER1_IO_SLAVEADDRESS);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);

    // read the port 0 input register port
    err = pca3535_register_read(OUTPUTPORTREGP0_ADDR, &read_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    write_data = read_data;   // copy the current state of the port.

    if (portdata & 0x20)
        write_data |= PMOD1_GPIO_IO6_MASK;   // set IO6
    else
        write_data &=(uint8_t) (~(PMOD1_GPIO_IO6_MASK)); // clear IO6

    // write the port 0 output register port
    err = pca3535_register_write(OUTPUTPORTREGP0_ADDR,write_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 1 output register port
    err = pca3535_register_read(OUTPUTPORTREGP1_ADDR, &read_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    write_data = read_data;   // copy the current state of the port.

    if (portdata & 0x40)
        write_data |= PMOD1_GPIO_IO7_MASK;   // set IO7
    else
        write_data &= (uint8_t)(~(PMOD1_GPIO_IO7_MASK)); // clear IO7

    if (portdata & 0x80)
        write_data |= PMOD1_GPIO_IO8_MASK;   // set IO8
    else
        write_data &= (uint8_t)(~(PMOD1_GPIO_IO8_MASK)); // clear IO8

    // write the port 1 output register port
    err = pca3535_register_write(OUTPUTPORTREGP1_ADDR,write_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);


}

//////////////////////////////////////////////////////////////////
//
// setup pmod I/O, Type, Power.
//
//
// input: u18port0cfg    = u18 port 0 pin direction  (PMOD RST/COM)
//        u18port1cfg    = u18 port 1 pin direction
//        u18port0outreg = u18 port 0 output register (PMOD IO7/8)
//        u18port1outreg = u18 port 1 output register
//        u19port0cfg    = u19 port 0 pin direction   (PMOD power)
//        u19port0outreg = u19 port 0 output register
//
//
// return: None
//////////////////////////////////////////////////////////////////

// IO Expander 1
// PORT 0 - 0=output, 1=input
// bit 0  PMOD4 RESET pin
// bit 1  PMOD3 RESET pin
// bit 2  PMOD2 RESET pin
// bit 3  PMOD1 RESET pin
// bit 4  PMOD4 COMMS Mode pin (Output only)
// bit 5  PMOD3 COMMS Mode pin (Output only)
// bit 6  PMOD2 COMMS Mode pin (Output only)
// bit 7  PMOD1 COMMS Mode pin (Output only)


// IO Expander 1
// PORT 1 - 0=output, 1=input
// bit 0  PMOD4 IO7 pin
// bit 1  PMOD4 IO8 pin
// bit 2  PMOD3 IO7 pin
// bit 3  PMOD3 IO8 pin
// bit 4  PMOD2 IO7 pin
// bit 5  PMOD2 IO8 pin
// bit 6  PMOD1 IO7 pin
// bit 7  PMOD1 IO8 pin

// IO Expander 2
// PORT 0 - 0=output, 1=input
// bit 0  NC (input only)
// bit 1  PMOD1 POWER pin (Output only)
// bit 2  PMOD2 POWER pin (Output only)
// bit 3  PMOD3 POWER pin (Output only)
// bit 4  PMOD4 POWER pin (Output only)
// bit 5  PMOD5 POWER pin (Output only)
// bit 6  PMOD6 POWER pin (Output only)
// bit 7  NC (input only)

void setup_pmod(    uint8_t u18port0cfg,
                    uint8_t u18port1cfg,
                    uint8_t u18port0outreg,
                    uint8_t u18port1outreg,
                    uint8_t u19port0cfg,
                    uint8_t u19port0outreg ) {
    ssp_err_t err;          // function return status
    uint8_t register_data;  // data from register read


    // open the driver
    err = pca3535_open();
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);

    /////////////////////////////////////////////////////////////////////////////////////

    // change the slave address for U18 expander
    err = pca3535_setslaveaddress(IOEXPANDER1_IO_SLAVEADDRESS);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);


    // write the port 0 configuration register port
    err = pca3535_register_write(CONFIGREGP0_ADDR,u18port0cfg);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 configuration register port
    err = pca3535_register_read(CONFIGREGP0_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (u18port0cfg != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);

    // write the port 0 output register port
    err = pca3535_register_write(OUTPUTPORTREGP0_ADDR,u18port0outreg);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 output register port (not input pin but the output register)
    err = pca3535_register_read(OUTPUTPORTREGP0_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (u18port0outreg != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);


    // write the port 1 configuration register port
    err = pca3535_register_write(CONFIGREGP1_ADDR,u18port1cfg);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 1 configuration register port
    err = pca3535_register_read(CONFIGREGP1_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (u18port1cfg != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);

    // write the port 1 output register port
    err = pca3535_register_write(OUTPUTPORTREGP1_ADDR,u18port1outreg);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 output register port (not input pin but the output register)
    err = pca3535_register_read(OUTPUTPORTREGP1_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (u18port1outreg != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);


    /////////////////////////////////////////////////////////////////////////////////////


    // change the slave address for U19 expander
    err = pca3535_setslaveaddress(IOEXPANDER2_PWR_SLAVEADDRESS);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);

    // write the port 0 configuration register port
    err = pca3535_register_write(CONFIGREGP0_ADDR,u19port0cfg);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 configuration register port
    err = pca3535_register_read(CONFIGREGP0_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (u19port0cfg != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);

    // write the port 0 output register port
    err = pca3535_register_write(OUTPUTPORTREGP0_ADDR,u19port0outreg);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 output register port (not input pin but the output register)
    err = pca3535_register_read(OUTPUTPORTREGP0_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (u19port0outreg != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);


}
/*-------------------------------------------------------------------------*
 * End of File:  pca9535.c
 *-------------------------------------------------------------------------*/
