
/*

    File:    Lesson 1 8 bits GPIO Output PMOD1
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    2/16/18

    SSP version: 1.20
    E2 Studio version: 5.4.0.023

    Description: Set 8 GPIO output on PMOD1.   Write different values to PMOD1 for testing purpose.

    Configuration: set COMMS mode U18 port0.1 = low

     IO.1 PA05 (S7G2)
     IO.2 PA04
     IO.3 PA03
     IO.4 PA02
     IO.5 P400
     IO.6 Reset (U18 IO Expander port 0.7)
     IO.7 IO7 (U18 IO Expander port 1.6)
     IO.8 IO8 (U18 IO Expander port 1.7)

    revision:
    v1: copy from gw002_u18_pca9535_v3
    v2: copy from gw002_u18_pca9535_v3c with fix on IO7/8
 *
 *
*/

/* HAL-only entry function */
#include "hal_data.h"
#include <pca9535/pca9535.h>


// GPIO Type 1
#define PMOD1_GPIO_IO1  IOPORT_PORT_10_PIN_05
#define PMOD1_GPIO_IO2  IOPORT_PORT_10_PIN_02
#define PMOD1_GPIO_IO3  IOPORT_PORT_10_PIN_03
#define PMOD1_GPIO_IO4  IOPORT_PORT_10_PIN_04
#define PMOD1_GPIO_IO5  IOPORT_PORT_04_PIN_00
#define PMOD1_GPIO_IO6_MASK  0B00001000     // port 0
#define PMOD1_GPIO_IO7_MASK  0B01000000     // port 1
#define PMOD1_GPIO_IO8_MASK  0B10000000     // port 1

#define LEDGRNPIN  IOPORT_PORT_11_PIN_06
#define LEDBLUPIN  IOPORT_PORT_11_PIN_07
#define LEDORGPIN  IOPORT_PORT_03_PIN_13
#define LEDREDPIN  IOPORT_PORT_03_PIN_14

void setup_pmod1_gpio(void);
void write_PMOD1_output (uint8_t portdata);

void hal_entry(void)
{

    g_ioport.p_api->pinWrite(LEDGRNPIN, IOPORT_LEVEL_HIGH);
    setup_pmod1_gpio();

    write_PMOD1_output(0x55);
    write_PMOD1_output(0xAA);

    while (true) {
        write_PMOD1_output(0x66);
        write_PMOD1_output(0x99);
    }
}



void write_PMOD1_output (uint8_t portdata) {
    ssp_err_t err;          // function return status
    uint8_t write_data;  // data to be written into the register
    uint8_t read_data;   // data to be red from the register

    if (portdata & 0x01)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO1, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO1, IOPORT_LEVEL_LOW);

    if (portdata & 0x02)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO2, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO2, IOPORT_LEVEL_LOW);

    if (portdata & 0x04)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO3, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO3, IOPORT_LEVEL_LOW);

    if (portdata & 0x08)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO4, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO4, IOPORT_LEVEL_LOW);

    if (portdata & 0x10)
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO5, IOPORT_LEVEL_HIGH);
    else
        g_ioport.p_api->pinWrite(PMOD1_GPIO_IO5, IOPORT_LEVEL_LOW);

    // change the slave address for U18 expander
    err = pca3535_setslaveaddress(IOEXPANDER1_IO_SLAVEADDRESS);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);

    // read the port 0 input register port
    err = pca3535_register_read(OUTPUTPORTREGP0_ADDR, &read_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    write_data = read_data;   // copy the current state of the port.

    if (portdata & 0x20)
        write_data |= PMOD1_GPIO_IO6_MASK;   // set IO6
    else
        write_data &=(uint8_t) (~(PMOD1_GPIO_IO6_MASK)); // clear IO6

    // write the port 0 output register port
    err = pca3535_register_write(OUTPUTPORTREGP0_ADDR,write_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 1 output register port
    err = pca3535_register_read(OUTPUTPORTREGP1_ADDR, &read_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    write_data = read_data;   // copy the current state of the port.

    if (portdata & 0x40)
        write_data |= PMOD1_GPIO_IO7_MASK;   // set IO7
    else
        write_data &= (uint8_t)(~(PMOD1_GPIO_IO7_MASK)); // clear IO7

    if (portdata & 0x80)
        write_data |= PMOD1_GPIO_IO8_MASK;   // set IO8
    else
        write_data &= (uint8_t)(~(PMOD1_GPIO_IO8_MASK)); // clear IO8

    // write the port 1 output register port
    err = pca3535_register_write(OUTPUTPORTREGP1_ADDR,write_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);


}

//
// setup pmod1 for 8 GPIO
// IO.1 PA05 (S7G2)
// IO.2 PA04
// IO.3 PA03
// IO.4 PA02
// IO.5 P400
// IO.6 Reset (U18 IO Expander port 0.7)
// IO.7 IO7 (U18 IO Expander port 1.6)
// IO.8 IO8 (U18 IO Expander port 1.7)

// Configuration U18 COMM = L (port 0.7)
// Direction     U18  Direction (all output)
// Power         U19 port 0.1 = H

void setup_pmod1_gpio(void) {
    ssp_err_t err;          // function return status
    uint8_t register_data;  // data from register read


    // open the driver
    err = pca3535_open();
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);

    /////////////////////////////////////////////////////////////////////////////////////

    // change the slave address for U18 expander
    err = pca3535_setslaveaddress(IOEXPANDER1_IO_SLAVEADDRESS);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);


    // write the port 0 configuration register port
    err = pca3535_register_write(CONFIGREGP0_ADDR,IOEX1_PORT0_CONFIG);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 configuration register port
    err = pca3535_register_read(CONFIGREGP0_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (IOEX1_PORT0_CONFIG != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);

    // write the port 0 output register port  (COMMS Mode bit 4 = L)
    err = pca3535_register_write(OUTPUTPORTREGP0_ADDR,0);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 output register port (not input pin but the output register)
    err = pca3535_register_read(OUTPUTPORTREGP0_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (0 != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);


    // write the port 1 configuration register port
    err = pca3535_register_write(CONFIGREGP1_ADDR,IOEX1_PORT1_CONFIG);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 1 configuration register port
    err = pca3535_register_read(CONFIGREGP1_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (IOEX1_PORT1_CONFIG != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);

    // write the port 1 output register port
    err = pca3535_register_write(OUTPUTPORTREGP1_ADDR,0);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 output register port (not input pin but the output register)
    err = pca3535_register_read(OUTPUTPORTREGP1_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (0 != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);


    /////////////////////////////////////////////////////////////////////////////////////


    // change the slave address for U19 expander
    err = pca3535_setslaveaddress(IOEXPANDER2_PWR_SLAVEADDRESS);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, IOPORT_LEVEL_HIGH);

    // write the port 0 configuration register port
    err = pca3535_register_write(CONFIGREGP0_ADDR,IOEX2_PORT0_CONFIG);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);

    // read the port 0 configuration register port
    err = pca3535_register_read(CONFIGREGP0_ADDR, &register_data);
    if (err)
        g_ioport.p_api->pinWrite(LEDREDPIN, true);
    if (IOEX2_PORT0_CONFIG != register_data)        // data verify
        g_ioport.p_api->pinWrite(LEDORGPIN, true);

}
