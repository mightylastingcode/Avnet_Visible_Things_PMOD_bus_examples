/*

    File: pca9535.c (IO Expander device driver)
    Name:    Michael Li
    Company: Consultant
    Web page: https://www.miketechuniverse.com/
    Date:    2/16/18

    SSP version: 1.20
    E2 Studio version: 5.4.0.023

    Description: Basic operations such register read and write

    Requirement: Create SCI_I2C driver (name: g_ioexpander_pmod) with Synergy Thread Configuration.
*/

#include "hal_data.h"
#include <pca9535/pca9535.h>
//#include "bsp_api.h"

// Open the driver
ssp_err_t pca3535_open(void) {
    return (g_ioexpander_pmod.p_api->open(g_ioexpander_pmod.p_ctrl,g_ioexpander_pmod.p_cfg));
}

// Write a byte to a register
ssp_err_t pca3535_register_write(uint8_t regaddr, uint8_t regdata) {
    uint8_t buf[2]; // buffer to hold command, write data

    buf[0] = regaddr;
    buf[1] = regdata;
    return(g_ioexpander_pmod.p_api->write(g_ioexpander_pmod.p_ctrl, buf, 2, false));
}

// Read a byte from a register
ssp_err_t pca3535_register_read(uint8_t regaddr, uint8_t *regdata) {
    uint8_t buf[2]; // buffer to hold command, write data
    ssp_err_t err;   // function return status

    // write the register address
    buf[0] = regaddr;
    err = g_ioexpander_pmod.p_api->write(g_ioexpander_pmod.p_ctrl, buf, 1, false);

    // read the register byte
    if (SSP_SUCCESS == err)
        err = g_ioexpander_pmod.p_api->read(g_ioexpander_pmod.p_ctrl, regdata, 1, false);

    return err;
}

// Set the slave address
ssp_err_t pca3535_setslaveaddress(uint8_t slaveaddr) {
    return (g_ioexpander_pmod.p_api->slaveAddressSet(g_ioexpander_pmod.p_ctrl, (uint16_t) slaveaddr, I2C_ADDR_MODE_7BIT));
}
